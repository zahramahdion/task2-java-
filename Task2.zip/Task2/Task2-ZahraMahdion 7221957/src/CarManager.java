import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CarManager {
    private List<Car> carList;

    public CarManager() {
        carList = new ArrayList<>();
    }

    public void addCar(Car car) {
        carList.add(car);
    }

    public void saveCarsByMake(String make) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(make + "_cars.txt"))) {
            for (Car car : carList) {
                if (car.getMake().equalsIgnoreCase(make)) {
                    writer.write(car.toString());
                    writer.newLine();
                }
            }
        }
    }

    public void saveCarsByModelAndAge(String model, int age) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(model + "_old_cars.txt"))) {
            int currentYear = 2023; // Replace with current year logic
            for (Car car : carList) {
                if (car.getModel().equalsIgnoreCase(model) && (currentYear - car.getYear() > age)) {
                    writer.write(car.toString());
                    writer.newLine();
                }
            }
        }
    }

    public void saveCarsByYearAndPrice(int year, double minPrice) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(year + "_expensive_cars.txt"))) {
            for (Car car : carList) {
                if (car.getYear() == year && car.getPrice() > minPrice) {
                    writer.write(car.toString());
                    writer.newLine();
                }
            }
        }
    }

    public static void main(String[] args) {
        CarManager manager = new CarManager();

        // Adding sample cars
        manager.addCar(new Car(1, "Toyota", "Camry", 2018, "Red", 24000, "ABC123"));
        manager.addCar(new Car(2, "Honda", "Civic", 2020, "Blue", 22000, "XYZ456"));
        manager.addCar(new Car(3, "Toyota", "Corolla", 2015, "Black", 18000, "DEF789"));
        manager.addCar(new Car(4, "Ford", "Focus", 2016, "White", 20000, "GHI012"));

        try {
            manager.saveCarsByMake("Toyota");
            manager.saveCarsByModelAndAge("Civic", 2);
            manager.saveCarsByYearAndPrice(2016, 19000);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}